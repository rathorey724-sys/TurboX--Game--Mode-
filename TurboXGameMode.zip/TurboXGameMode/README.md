# TurboX Game Mode (Android 14 / 15 / 16+ & Xiaomi HyperOS)

## Phone-Only GitHub Actions APK Build Steps
1. Upload `TurboXGameMode.zip` to your GitHub repository (`Add file -> Upload files -> Commit`).
2. Create `.github/workflows/build.yml` (`Add file -> Create new file`) using the workflow file inside this ZIP.
3. Open the **Actions** tab on GitHub, wait 2–3 minutes for the green checkmark, and download **TurboX-Game-Mode-APK** under **Artifacts**.
4. Extract the artifact ZIP and install `app-debug.apk` on your Redmi Note 15.

## Optional Shizuku Setup (Non-Root Performance Mode)
1. Install **Shizuku** from Google Play / GitHub.
2. Enable **Developer Options -> Wireless debugging** on HyperOS and pair Shizuku.
3. Open **TurboX Game Mode -> Setup -> 7. Connect Optional Shizuku Turbo** and tap Allow.

## Frame-Time Stability Test Plan (ADB / Wireless Debugging)
1. Reset frame stats before match:
   `adb shell dumpsys gfxinfo <freefire.package.name> reset`
2. Play a 10-minute Bermuda Ranked match with TurboX **Performance** profile active.
3. Dump frame metrics:
   `adb shell dumpsys gfxinfo <freefire.package.name>`
   Check `Janky frames %`, `90th percentile`, and `95th percentile` frame times against baseline.

## Known Honest Limitations
- **Voice Changer Routing:** Non-rooted Android prevents apps from injecting virtual microphone audio directly into another app's voice chat. Use Bluetooth/speaker routing or record & share `.wav` clips.
- **Display Hz vs Game FPS:** Overlay shows real hardware refresh rate (`Display Hz`). Actual game FPS is controlled by Free Fire's in-game graphics settings.
