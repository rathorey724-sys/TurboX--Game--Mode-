package com.turbox.gamemode

import android.app.ActivityManager
import android.app.GameManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.net.InetSocketAddress
import java.net.Socket

object PerformanceEngine {

    private val protectedPrefixes = listOf(
        "com.android.", "android", "com.google.android.gms", "com.google.android.inputmethod",
        "com.miui.", "com.xiaomi.", "com.turbox.gamemode"
    )

    fun isShizukuReady(): Boolean {
        return try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
    }

    fun requestShizukuIfAvailable(): String {
        return try {
            if (!Shizuku.pingBinder()) {
                "Shizuku Not Running (Optional)"
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                "Shizuku Turbo: ACTIVE (Non-Root Ready)"
            } else {
                Shizuku.requestPermission(1001)
                "Shizuku Permission Requested..."
            }
        } catch (_: Throwable) {
            "Shizuku Not Installed (Using Standard Engine)"
        }
    }

    fun cleanBackgroundRam(context: Context): Long {
        val before = HardwareInspector.getFreeRamMb(context)
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
        for (app in apps) {
            val pkg = app.packageName
            if (protectedPrefixes.any { pkg.startsWith(it) }) continue
            if (pkg.contains("freefire", ignoreCase = true)) continue
            try {
                am.killBackgroundProcesses(pkg)
            } catch (_: Exception) {
            }
        }
        val after = HardwareInspector.getFreeRamMb(context)
        return (after - before).coerceAtLeast(0L)
    }

    fun applyProfileForPackage(context: Context, pkg: String, profile: TurboProfile): String {
        if (pkg.isBlank()) return "No target game selected"
        val notes = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val gm = context.getSystemService(GameManager::class.java)
                gm?.setGameMode(pkg, profile.gameModeValue)
                notes.add("GameManager=${profile.label}")
            } catch (_: Throwable) {
                notes.add("GameManager=Fallback")
            }
        }

        if (isShizukuReady()) {
            try {
                val proc = Shizuku.newProcess(arrayOf("cmd", "game", "mode", profile.shizukuMode, pkg), null, null)
                proc.waitFor()
                notes.add("Shizuku(${profile.shizukuMode})=OK")
            } catch (_: Throwable) {
                notes.add("Shizuku=Skipped")
            }
        }
        return notes.joinToString(" | ").ifEmpty { "Profile ${profile.label} active" }
    }

    fun setDndEnabled(context: Context, enable: Boolean) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) return
            val filter = if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(filter)
        } catch (_: Exception) {
        }
    }

    fun setLobbyBrightness(context: Context, dim: Boolean) {
        try {
            if (!Settings.System.canWrite(context)) return
            val value = if (dim) 45 else 160
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
        } catch (_: Exception) {
        }
    }

    fun readBatteryInfo(context: Context): Pair<Int, Float> {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 80) ?: 80
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 340) ?: 340
        return level to (tempTenths / 10f)
    }

    fun readThermalStatus(context: Context): String {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Cool"
                PowerManager.THERMAL_STATUS_LIGHT -> "Warm"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Hot (Throttling)"
                else -> "Critical"
            }
        } else "Normal"
    }

    suspend fun measurePingMs(): Int = withContext(Dispatchers.IO) {
        try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress("1.1.1.1", 53), 1200)
            }
            (System.currentTimeMillis() - start).toInt()
        } catch (_: Exception) {
            -1
        }
    }

    fun openHyperOsAutostart(context: Context): Boolean {
        val intents = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT)
        )
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return true
            } catch (_: Exception) {
            }
        }
        return false
    }
}
