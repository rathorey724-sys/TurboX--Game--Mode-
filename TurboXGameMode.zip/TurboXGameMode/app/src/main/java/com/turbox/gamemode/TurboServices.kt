package com.turbox.gamemode

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TurboMonitorService : Service() {
    companion object {
        const val ACTION_START = "com.turbox.gamemode.MONITOR_START"
        const val ACTION_STOP = "com.turbox.gamemode.MONITOR_STOP"
        var isRunning = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var monitorJob: Job? = null
    private var windowManager: WindowManager? = null
    private var hudView: View? = null
    private var isScreenOn = true
    private var sessionStartMs = 0L
    private var startBattery = 80
    private var peakTemp = 34f

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> isScreenOn = false
                Intent.ACTION_SCREEN_ON -> isScreenOn = true
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        sessionStartMs = System.currentTimeMillis()
        val (bat, temp) = PerformanceEngine.readBatteryInfo(this)
        startBattery = bat
        peakTemp = temp
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        val notif = buildNotification("TurboX HUD & Thermal Guard Active")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(this, 101, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(101, notif)
        }
        attachHudOverlay()
        startTelemetryLoop()
        return START_STICKY
    }

    private fun startTelemetryLoop() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            val prefs = TurboPrefs(this@TurboMonitorService)
            var tick = 0
            var pingMs = 45
            while (isActive) {
                if (isScreenOn) {
                    val (bat, temp) = PerformanceEngine.readBatteryInfo(this@TurboMonitorService)
                    if (temp > peakTemp) peakTemp = temp
                    val freeRam = HardwareInspector.getFreeRamMb(this@TurboMonitorService)
                    val hz = HardwareInspector.getDisplayHz(this@TurboMonitorService)
                    val thermal = PerformanceEngine.readThermalStatus(this@TurboMonitorService)

                    if (tick % 5 == 0) {
                        pingMs = PerformanceEngine.measurePingMs()
                    }
                    if (prefs.thermalGuard && temp >= 42.5f && prefs.selectedProfile != TurboProfile.BATTERY_SAVER) {
                        val stepped = prefs.selectedProfile.stepDown()
                        prefs.selectedProfile = stepped
                        PerformanceEngine.applyProfileForPackage(this@TurboMonitorService, prefs.activeGamePackage, stepped)
                    }

                    val pingLabel = if (pingMs > 0) "${pingMs}ms" else "Offline"
                    val summary = "TURBOX | ${prefs.selectedProfile.label}
" +
                            "Temp: ${temp}°C ($thermal) | Bat: $bat%
" +
                            "RAM: ${freeRam}MB | Display: ${hz}Hz | Ping: $pingLabel"
                    (hudView?.findViewWithTag<TextView>("hud_text"))?.text = summary
                    tick++
                }
                delay(1500L)
            }
        }
    }

    private fun attachHudOverlay() {
        if (hudView != null || !Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_hud)
            setPadding(24, 16, 24, 16)
        }
        val tv = TextView(this).apply {
            tag = "hud_text"
            setTextColor(Color.WHITE)
            textSize = 11f
            text = "TURBOX HUD Initializing..."
        }
        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 0)
        }
        val btnNextVoice = TextView(this).apply {
            text = " [Next Voice] "
            setTextColor(Color.parseColor("#FF6A00"))
            textSize = 11f
            setOnClickListener {
                val next = VoiceChangerService.engine.nextPreset()
                tv.text = "Voice Switched: ${next.displayName}"
            }
        }
        val btnClose = TextView(this).apply {
            text = " [Hide HUD] "
            setTextColor(Color.parseColor("#FF2E3B"))
            textSize = 11f
            setOnClickListener { stopSelf() }
        }
        quickRow.addView(btnNextVoice)
        quickRow.addView(btnClose)
        container.addView(tv)
        container.addView(quickRow)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 140
        }

        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x; initY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initX + (event.rawX - touchX).toInt()
                    params.y = initY + (event.rawY - touchY).toInt()
                    windowManager?.updateViewLayout(container, params)
                    true
                }
                else -> false
            }
        }
        hudView = container
        windowManager?.addView(container, params)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("turbox_monitor", "TurboX Monitor", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "turbox_monitor")
            .setSmallIcon(R.drawable.ic_turbo)
            .setContentTitle("TurboX Game Mode")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    override fun onTimeout(startId: Int) {
        stopSelf()
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }

    override fun onDestroy() {
        isRunning = false
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        hudView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        hudView = null

        val prefs = TurboPrefs(this)
        if (prefs.autoDnd) PerformanceEngine.setDndEnabled(this, false)
        val mins = ((System.currentTimeMillis() - sessionStartMs) / 60000L).toInt().coerceAtLeast(1)
        val (endBat, _) = PerformanceEngine.readBatteryInfo(this)
        prefs.addSession(SessionStat("Game Session", mins, peakTemp, (startBattery - endBat).coerceAtLeast(0)))

        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class VoiceChangerService : Service() {
    companion object {
        const val ACTION_START = "com.turbox.gamemode.VOICE_START"
        const val ACTION_STOP = "com.turbox.gamemode.VOICE_STOP"
        const val ACTION_NEXT = "com.turbox.gamemode.VOICE_NEXT"
        val engine = DspVoiceEngine()
        var isRunning = false
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                engine.stop()
                isRunning = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_NEXT -> {
                engine.nextPreset()
                return START_STICKY
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("turbox_voice", "TurboX Voice DSP", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val nextPi = PendingIntent.getService(
            this, 2, Intent(this, VoiceChangerService::class.java).setAction(ACTION_NEXT), PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 3, Intent(this, VoiceChangerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, "turbox_voice")
            .setSmallIcon(R.drawable.ic_turbo)
            .setContentTitle("TurboX Real-Time Voice DSP")
            .setContentText("Active Voice: ${engine.activePreset.get().displayName}")
            .addAction(0, "Next Voice", nextPi)
            .addAction(0, "Stop", stopPi)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceCompat.startForeground(this, 102, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(102, notif)
        }
        isRunning = true
        engine.start()
        return START_STICKY
    }

    override fun onTimeout(startId: Int) {
        engine.stop()
        isRunning = false
        stopSelf()
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        engine.stop()
        isRunning = false
        stopSelf()
    }

    override fun onDestroy() {
        engine.stop()
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class ScreenRecordService : Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("turbox_rec", "TurboX Capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(this, "turbox_rec")
            .setSmallIcon(R.drawable.ic_turbo)
            .setContentTitle("TurboX Capture Ready")
            .setContentText("MediaProjection session standby")
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, 103, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(103, notif)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
