package com.turbox.gamemode

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat

@RequiresApi(Build.VERSION_CODES.N)
class TurboTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = if (TurboMonitorService.isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, TurboMonitorService::class.java).apply {
            action = if (TurboMonitorService.isRunning) TurboMonitorService.ACTION_STOP else TurboMonitorService.ACTION_START
        }
        if (TurboMonitorService.isRunning) {
            startService(intent)
        } else {
            ContextCompat.startForegroundService(this, intent)
        }
        qsTile?.apply {
            state = if (!TurboMonitorService.isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }
}

class TurboWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_turbo)
            val intent = Intent(context, TurboWidgetProvider::class.java).setAction("com.turbox.gamemode.ACTION_WIDGET_BOOST")
            val pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widgetRoot, pi)
            appWidgetManager.updateAppWidget(id, views)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.turbox.gamemode.ACTION_WIDGET_BOOST") {
            val freed = PerformanceEngine.cleanBackgroundRam(context)
            val prefs = TurboPrefs(context)
            val pkg = prefs.activeGamePackage.ifEmpty {
                GameRepository.loadGames(context, prefs).firstOrNull()?.packageName ?: ""
            }
            if (pkg.isNotEmpty()) {
                PerformanceEngine.applyProfileForPackage(context, pkg, prefs.selectedProfile)
                context.packageManager.getLaunchIntentForPackage(pkg)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(it)
                }
            }
            Toast.makeText(context, "TurboX Boosted! Freed ${freed}MB RAM", Toast.LENGTH_SHORT).show()
        }
    }
}

class SessionChartView(context: Context, private val stats: List<SessionStat>) : View(context) {
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF2E3B") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#171720"))
        if (stats.isEmpty()) {
            canvas.drawText("No sessions recorded yet.", 30f, 80f, textPaint)
            return
        }
        val maxMins = stats.maxOf { it.durationMinutes }.coerceAtLeast(1)
        val barWidth = (width - 80f) / stats.size.coerceAtMost(6)
        stats.take(6).forEachIndexed { idx, s ->
            val left = 40f + idx * barWidth + 10f
            val right = left + barWidth - 20f
            val barHeight = (s.durationMinutes.toFloat() / maxMins) * (height - 120f)
            val top = height - 60f - barHeight
            canvas.drawRect(left, top, right, height - 60f, barPaint)
            canvas.drawText("${s.durationMinutes}m", left, top - 8f, textPaint)
            canvas.drawText("${s.peakTempC}°", left, height - 24f, textPaint)
        }
    }
}
