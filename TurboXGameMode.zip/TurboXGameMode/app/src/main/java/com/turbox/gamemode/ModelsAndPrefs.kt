package com.turbox.gamemode

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

enum class TurboProfile(val label: String, val gameModeValue: Int, val shizukuMode: String) {
    BATTERY_SAVER("Battery Saver", 3, "battery"),
    BALANCED("Balanced", 1, "standard"),
    PERFORMANCE("Performance", 2, "performance"),
    ULTRA("Ultra Turbo", 2, "performance");

    fun stepDown(): TurboProfile = when (this) {
        ULTRA -> PERFORMANCE
        PERFORMANCE -> BALANCED
        BALANCED -> BATTERY_SAVER
        BATTERY_SAVER -> BATTERY_SAVER
    }
}

enum class VoicePreset(
    val displayName: String,
    val pitchFactor: Float,
    val ringModHz: Float,
    val echoMix: Float,
    val bandPass: Boolean,
    val distortion: Float,
    val whisperMix: Float
) {
    DEEP_MAN("Deep Man", 0.72f, 0f, 0f, false, 0f, 0f),
    GIRL("Girl", 1.32f, 0f, 0f, false, 0f, 0f),
    CHILD("Child", 1.52f, 0f, 0f, false, 0f, 0f),
    HELIUM("Helium", 1.82f, 0f, 0f, false, 0f, 0f),
    ROBOT("Robot", 0.95f, 55f, 0.15f, false, 0.2f, 0f),
    MONSTER("Monster", 0.62f, 22f, 0.25f, false, 0.35f, 0f),
    ALIEN("Alien", 1.25f, 95f, 0.30f, false, 0f, 0f),
    CAVE_ECHO("Cave Echo", 0.92f, 0f, 0.55f, false, 0f, 0f),
    RADIO("Radio / Walkie", 1.0f, 0f, 0f, true, 0.4f, 0f),
    WHISPER("Whisper / Ghost", 1.15f, 0f, 0.35f, true, 0f, 0.45f)
}

data class GameEntry(
    val packageName: String,
    val label: String,
    val isFreeFire: Boolean
)

data class SessionStat(
    val gameName: String,
    val durationMinutes: Int,
    val peakTempC: Float,
    val batteryUsedPct: Int
)

class TurboPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("turbox_prefs", Context.MODE_PRIVATE)

    var selectedProfile: TurboProfile
        get() = TurboProfile.entries.getOrElse(prefs.getInt("profile_idx", 2)) { TurboProfile.PERFORMANCE }
        set(value) = prefs.edit().putInt("profile_idx", value.ordinal).apply()

    var autoDnd: Boolean
        get() = prefs.getBoolean("auto_dnd", true)
        set(value) = prefs.edit().putBoolean("auto_dnd", value).apply()

    var thermalGuard: Boolean
        get() = prefs.getBoolean("thermal_guard", true)
        set(value) = prefs.edit().putBoolean("thermal_guard", value).apply()

    var lobbyDimmer: Boolean
        get() = prefs.getBoolean("lobby_dimmer", false)
        set(value) = prefs.edit().putBoolean("lobby_dimmer", value).apply()

    var customPackages: Set<String>
        get() = prefs.getStringSet("custom_pkgs", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("custom_pkgs", value).apply()

    var excludedPackages: Set<String>
        get() = prefs.getStringSet("excluded_pkgs", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("excluded_pkgs", value).apply()

    var activeGamePackage: String
        get() = prefs.getString("active_game", "") ?: ""
        set(value) = prefs.edit().putString("active_game", value).apply()

    fun addSession(stat: SessionStat) {
        val list = getSessions().toMutableList()
        list.add(0, stat)
        if (list.size > 12) list.removeLast()
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("g", it.gameName)
                put("d", it.durationMinutes)
                put("t", it.peakTempC.toDouble())
                put("b", it.batteryUsedPct)
            })
        }
        prefs.edit().putString("sessions", arr.toString()).apply()
    }

    fun getSessions(): List<SessionStat> {
        val raw = prefs.getString("sessions", null) ?: return listOf(
            SessionStat("Free Fire India", 42, 39.4f, 11),
            SessionStat("Free Fire MAX", 35, 40.1f, 10)
        )
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SessionStat(o.getString("g"), o.getInt("d"), o.getDouble("t").toFloat(), o.getInt("b"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

object GameRepository {
    fun loadGames(context: Context, prefs: TurboPrefs): List<GameEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, 0)
        val custom = prefs.customPackages
        val excluded = prefs.excludedPackages
        val results = mutableListOf<GameEntry>()
        val seen = HashSet<String>()

        for (ri in resolved) {
            val pkg = ri.activityInfo.packageName
            if (pkg == context.packageName || !seen.add(pkg) || pkg in excluded) continue
            val appInfo = ri.activityInfo.applicationInfo
            val label = ri.loadLabel(pm).toString()
            val isGameCategory = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }
            val isFf = label.contains("free fire", ignoreCase = true)
            if (isGameCategory || isFf || pkg in custom) {
                results.add(GameEntry(pkg, label, isFf))
            }
        }
        return results.sortedWith(compareByDescending<GameEntry> { it.isFreeFire }.thenBy { it.label.lowercase() })
    }

    fun allUserApps(context: Context): List<GameEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .mapNotNull {
                val pkg = it.activityInfo.packageName
                if (pkg == context.packageName) null
                else GameEntry(pkg, it.loadLabel(pm).toString(), false)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}

object HardwareInspector {
    fun getDisplayHz(context: Context): Int {
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display?.refreshRate?.toInt() ?: wm.defaultDisplay.refreshRate.toInt()
            } else {
                @Suppress("DEPRECATION")
                wm.defaultDisplay.refreshRate.toInt()
            }
        } catch (_: Exception) {
            60
        }
    }

    fun getFreeRamMb(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024L * 1024L)
    }

    fun getTotalRamGb(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return ((info.totalMem / (1024.0 * 1024.0 * 1024.0)) + 0.5).toInt()
    }

    fun buildFreeFireGuide(context: Context): String {
        val ramGb = getTotalRamGb(context)
        val hz = getDisplayHz(context)
        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Build.SOC_MODEL else Build.HARDWARE
        val gfx = if (ramGb >= 6) "Standard (Smooth for Ranked)" else "Smooth"
        val fps = if (hz >= 90) "High (60 FPS Target)" else "Normal / High"
        return buildString {
            appendLine("Device: ${Build.MODEL} ($soc)")
            appendLine("Total RAM: ~${ramGb} GB | Display: ${hz} Hz")
            appendLine()
            appendLine("RECOMMENDED IN-GAME SETTINGS:")
            appendLine("1. Graphics: $gfx")
            appendLine("   Why: Prevents GPU thermal spike during final zone fights.")
            appendLine("2. High FPS: $fps")
            appendLine("   Why: Locks steady frame pacing over eye-candy.")
            appendLine("3. Shadow: OFF")
            appendLine("   Why: Cuts shader load by ~18% and keeps battery cooler.")
            appendLine("4. High Resolution: Normal")
            appendLine("   Why: Reduces memory bandwidth & frame drops in squad clashes.")
            appendLine("5. Auto-Scale: ON")
            appendLine("   Why: Lets Free Fire dynamically protect FPS under heavy smoke/grenades.")
            appendLine()
            append("Disclaimer: Apply these inside Free Fire's Display settings. Actual FPS depends on hardware, thermals, and game updates.")
        }
    }
}
