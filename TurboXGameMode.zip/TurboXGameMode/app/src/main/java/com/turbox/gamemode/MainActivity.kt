package com.turbox.gamemode

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: TurboPrefs
    private lateinit var txtTelemetry: TextView
    private lateinit var txtShizukuStatus: TextView
    private lateinit var containerGames: LinearLayout
    private lateinit var btnToggleHud: Button
    private lateinit var btnToggleVoice: Button
    private lateinit var btnRecordWav: Button

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            txtShizukuStatus.text = "Shizuku Turbo: ACTIVE (Non-Root Ready)"
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        prefs = TurboPrefs(this)

        val root = findViewById<ScrollView>(R.id.rootScroll)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}

        txtTelemetry = findViewById(R.id.txtTelemetry)
        txtShizukuStatus = findViewById(R.id.txtShizukuStatus)
        containerGames = findViewById(R.id.containerGames)
        btnToggleHud = findViewById(R.id.btnToggleHud)
        btnToggleVoice = findViewById(R.id.btnToggleVoice)
        btnRecordWav = findViewById(R.id.btnRecordWav)

        setupProfileControls()
        setupVoiceControls()
        setupButtons()
        loadGameLibrary()
        startLiveDashboardTicker()
    }

    private fun setupProfileControls() {
        val spinner = findViewById<Spinner>(R.id.spinnerProfile)
        val labels = TurboProfile.entries.map { it.label }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spinner.setSelection(prefs.selectedProfile.ordinal)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                prefs.selectedProfile = TurboProfile.entries[pos]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val chkDnd = findViewById<CheckBox>(R.id.chkAutoDnd)
        chkDnd.isChecked = prefs.autoDnd
        chkDnd.setOnCheckedChangeListener { _, checked -> prefs.autoDnd = checked }

        val chkThermal = findViewById<CheckBox>(R.id.chkThermalGuard)
        chkThermal.isChecked = prefs.thermalGuard
        chkThermal.setOnCheckedChangeListener { _, checked -> prefs.thermalGuard = checked }
    }

    private fun setupVoiceControls() {
        val spinner = findViewById<Spinner>(R.id.spinnerVoice)
        val names = VoicePreset.entries.map { it.displayName }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                VoiceChangerService.engine.activePreset.set(VoicePreset.entries[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        findViewById<CheckBox>(R.id.chkAutoCycle).setOnCheckedChangeListener { _, checked ->
            VoiceChangerService.engine.autoCycle.set(checked)
        }
        findViewById<CheckBox>(R.id.chkShuffleVoice).setOnCheckedChangeListener { _, checked ->
            VoiceChangerService.engine.shuffleMode.set(checked)
        }

        btnToggleVoice.setOnClickListener {
            if (VoiceChangerService.isRunning) {
                startService(Intent(this, VoiceChangerService::class.java).setAction(VoiceChangerService.ACTION_STOP))
                btnToggleVoice.text = "Start Voice"
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                    return@setOnClickListener
                }
                ContextCompat.startForegroundService(this, Intent(this, VoiceChangerService::class.java).setAction(VoiceChangerService.ACTION_START))
                btnToggleVoice.text = "Stop Voice"
            }
        }

        btnRecordWav.setOnClickListener {
            val engine = VoiceChangerService.engine
            if (!VoiceChangerService.isRunning) {
                Toast.makeText(this, "Tap 'Start Voice' first to record!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!engine.isRecordingWav.get()) {
                engine.startRecording()
                btnRecordWav.text = "Save & Share WAV"
                Toast.makeText(this, "Recording processed voice...", Toast.LENGTH_SHORT).show()
            } else {
                val dir = File(cacheDir, "recordings").apply { mkdirs() }
                val file = File(dir, "turbox_voice_${System.currentTimeMillis()}.wav")
                engine.stopAndSaveWav(file)
                btnRecordWav.text = "Record WAV"
                shareWavFile(file)
            }
        }
    }

    private fun shareWavFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Share Voice Clip"))
        } catch (e: Exception) {
            Toast.makeText(this, "Saved to ${file.name}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnSetupWizard).setOnClickListener { showSetupWizardDialog() }

        findViewById<Button>(R.id.btnCleanRam).setOnClickListener {
            val freed = PerformanceEngine.cleanBackgroundRam(this)
            Toast.makeText(this, "Freed ~${freed} MB background RAM", Toast.LENGTH_SHORT).show()
            refreshStatus()
        }

        btnToggleHud.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant 'Display over other apps' first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (TurboMonitorService.isRunning) {
                startService(Intent(this, TurboMonitorService::class.java).setAction(TurboMonitorService.ACTION_STOP))
                btnToggleHud.text = "Start HUD"
            } else {
                ContextCompat.startForegroundService(this, Intent(this, TurboMonitorService::class.java).setAction(TurboMonitorService.ACTION_START))
                btnToggleHud.text = "Stop HUD"
            }
        }

        findViewById<Button>(R.id.btnAddGame).setOnClickListener { showAddAppDialog() }

        findViewById<Button>(R.id.btnFfGuide).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Free Fire Settings Assistant")
                .setMessage(HardwareInspector.buildFreeFireGuide(this))
                .setPositiveButton("Got It", null)
                .show()
        }

        findViewById<Button>(R.id.btnCoolDown).setOnClickListener {
            val (bat, temp) = PerformanceEngine.readBatteryInfo(this)
            val thermal = PerformanceEngine.readThermalStatus(this)
            AlertDialog.Builder(this)
                .setTitle("Thermal Cool-Down Monitor")
                .setMessage(
                    "Current Temp: ${temp}°C ($thermal)
Battery: $bat%

" +
                    "Cooling Checklist:
" +
                    "• Remove thick phone case during long ranked sessions
" +
                    "• Avoid charging while playing Free Fire
" +
                    "• Lower screen brightness to ~50% in lobby
" +
                    "• Close background video/social apps"
                )
                .setPositiveButton("Clean Background Apps") { _, _ ->
                    val freed = PerformanceEngine.cleanBackgroundRam(this)
                    Toast.makeText(this, "Cleaned! Freed ${freed}MB", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Close", null)
                .show()
        }

        findViewById<Button>(R.id.btnStats).setOnClickListener {
            val stats = prefs.getSessions()
            val chart = SessionChartView(this, stats).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 420)
            }
            AlertDialog.Builder(this)
                .setTitle("Session Duration (mins) & Peak Temp")
                .setView(chart)
                .setPositiveButton("Close", null)
                .show()
        }
    }

    private fun loadGameLibrary() {
        containerGames.removeAllViews()
        val games = GameRepository.loadGames(this, prefs)
        if (games.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No games auto-detected. Tap '+ Add App' to add Free Fire or any game."
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
                textSize = 13f
            }
            containerGames.addView(emptyTv)
            return
        }

        for (game in games) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.card_elevated))
                setPadding(24, 18, 24, 18)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.topMargin = 12
                layoutParams = lp
            }
            val title = TextView(this).apply {
                text = if (game.isFreeFire) "🔥 ${game.label}" else game.label
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val boostBtn = Button(this).apply {
                text = "Boost & Launch"
                textSize = 12f
                setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.accent_red))
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                setOnClickListener { boostAndLaunch(game) }
            }
            row.addView(title)
            row.addView(boostBtn)
            containerGames.addView(row)
        }
    }

    private fun boostAndLaunch(game: GameEntry) {
        prefs.activeGamePackage = game.packageName
        val freed = PerformanceEngine.cleanBackgroundRam(this)
        val status = PerformanceEngine.applyProfileForPackage(this, game.packageName, prefs.selectedProfile)
        if (prefs.autoDnd) PerformanceEngine.setDndEnabled(this, true)
        if (Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(this, Intent(this, TurboMonitorService::class.java).setAction(TurboMonitorService.ACTION_START))
        }
        Toast.makeText(this, "Boosted! Freed ${freed}MB | $status", Toast.LENGTH_LONG).show()
        val launch = packageManager.getLaunchIntentForPackage(game.packageName)
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Unable to open ${game.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAddAppDialog() {
        val apps = GameRepository.allUserApps(this)
        val names = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add Game / App to TurboX")
            .setItems(names) { _, which ->
                val chosen = apps[which]
                prefs.customPackages = prefs.customPackages + chosen.packageName
                loadGameLibrary()
            }
            .show()
    }

    private fun showSetupWizardDialog() {
        val items = arrayOf(
            "1. Grant Runtime Permissions (Mic & Notifications)",
            "2. Enable Floating HUD Overlay Permission",
            "3. Enable Usage Access (Foreground Game Detection)",
            "4. Enable Do Not Disturb Access",
            "5. Xiaomi HyperOS: Enable Autostart",
            "6. Xiaomi HyperOS: Battery 'No Restrictions'",
            "7. Connect Optional Shizuku Turbo"
        )
        AlertDialog.Builder(this)
            .setTitle("HyperOS & Permissions Setup")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            perms.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        permLauncher.launch(perms.toTypedArray())
                    }
                    1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    2 -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    3 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    4 -> {
                        if (!PerformanceEngine.openHyperOsAutostart(this)) {
                            Toast.makeText(this, "Open Settings > Apps > Manage Apps > TurboX > Autostart", Toast.LENGTH_LONG).show()
                        }
                    }
                    5 -> {
                        try {
                            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }
                    }
                    6 -> {
                        txtShizukuStatus.text = PerformanceEngine.requestShizukuIfAvailable()
                    }
                }
            }
            .setNegativeButton("Done", null)
            .show()
    }

    private fun startLiveDashboardTicker() {
        lifecycleScope.launch {
            while (isActive) {
                refreshStatus()
                delay(2000L)
            }
        }
    }

    private fun refreshStatus() {
        val (bat, temp) = PerformanceEngine.readBatteryInfo(this)
        val ram = HardwareInspector.getFreeRamMb(this)
        val hz = HardwareInspector.getDisplayHz(this)
        txtTelemetry.text = "Free RAM: ${ram} MB | Temp: ${temp}°C | Bat: $bat% | Display: ${hz} Hz"
        txtShizukuStatus.text = if (PerformanceEngine.isShizukuReady()) {
            "Shizuku Turbo: ACTIVE (Non-Root System Boost Ready)"
        } else {
            "Shizuku Turbo: Optional (Tap Setup > 7 to link)"
        }
        btnToggleHud.text = if (TurboMonitorService.isRunning) "Stop HUD" else "Start HUD"
        btnToggleVoice.text = if (VoiceChangerService.isRunning) "Stop Voice" else "Start Voice"
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
