package com.turbox.gamemode

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

class DspVoiceEngine {
    val activePreset = AtomicReference(VoicePreset.DEEP_MAN)
    val autoCycle = AtomicBoolean(false)
    val shuffleMode = AtomicBoolean(false)
    val isRecordingWav = AtomicBoolean(false)

    private val running = AtomicBoolean(false)
    private var workerThread: Thread? = null
    private val wavBuffer = ByteArrayOutputStream()

    private val sampleRate = 24000

    @SuppressLint("MissingPermission")
    fun start() {
        if (running.getAndSet(true)) return
        workerThread = Thread({
            val minRec = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(1024)
            val minPlay = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(1024)

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minRec * 2
            )

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minPlay * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val frameSize = 512
            val inBuf = ShortArray(frameSize)
            val outBuf = ShortArray(frameSize)
            val ringBuf = FloatArray(4096)
            val echoBuf = FloatArray(sampleRate / 3)
            var writePos = 0
            var readPhase = 0f
            var echoIdx = 0
            var modPhase = 0.0
            var lpState = 0f
            var lastCycleTime = System.currentTimeMillis()

            try {
                recorder.startRecording()
                track.play()
                while (running.get()) {
                    if (autoCycle.get() && System.currentTimeMillis() - lastCycleTime > 10_000L) {
                        lastCycleTime = System.currentTimeMillis()
                        nextPreset()
                    }
                    val read = recorder.read(inBuf, 0, frameSize)
                    if (read <= 0) continue

                    val preset = activePreset.get()
                    for (i in 0 until read) {
                        ringBuf[writePos and 4095] = inBuf[i] / 32768f
                        writePos++
                    }

                    for (i in 0 until read) {
                        val idx0 = readPhase.toInt()
                        val frac = readPhase - idx0
                        val s0 = ringBuf[idx0 and 4095]
                        val s1 = ringBuf[(idx0 + 1) and 4095]
                        var sample = s0 + (s1 - s0) * frac
                        readPhase += preset.pitchFactor
                        if (writePos - readPhase > 3000f || writePos - readPhase < 64f) {
                            readPhase = (writePos - 512).toFloat()
                        }

                        if (preset.ringModHz > 0f) {
                            modPhase += 2.0 * PI * preset.ringModHz / sampleRate
                            sample *= sin(modPhase).toFloat()
                        }
                        if (preset.bandPass) {
                            lpState += 0.25f * (sample - lpState)
                            sample = sample - lpState * 0.7f
                        }
                        if (preset.distortion > 0f) {
                            sample = tanh((sample * (1f + preset.distortion * 5f)).toDouble()).toFloat()
                        }
                        if (preset.whisperMix > 0f) {
                            val noise = (Random.nextFloat() * 2f - 1f) * 0.25f
                            sample = sample * (1f - preset.whisperMix) + noise * kotlin.math.abs(sample) * 3f
                        }
                        if (preset.echoMix > 0f) {
                            val delayed = echoBuf[echoIdx]
                            echoBuf[echoIdx] = sample + delayed * 0.45f
                            echoIdx = (echoIdx + 1) % echoBuf.size
                            sample += delayed * preset.echoMix
                        }

                        val limited = tanh(sample.toDouble()).toFloat()
                        outBuf[i] = (limited * 30000f).toInt().coerceIn(-32767, 32767).toShort()
                    }

                    track.write(outBuf, 0, read)

                    if (isRecordingWav.get()) {
                        synchronized(wavBuffer) {
                            val bb = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                            for (i in 0 until read) bb.putShort(outBuf[i])
                            wavBuffer.write(bb.array())
                        }
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { recorder.stop(); recorder.release() } catch (_: Exception) {}
                try { track.stop(); track.release() } catch (_: Exception) {}
            }
        }, "TurboX-DSP").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        running.set(false)
        workerThread?.interrupt()
        workerThread = null
    }

    fun nextPreset(): VoicePreset {
        val all = VoicePreset.entries
        val current = activePreset.get()
        val next = if (shuffleMode.get()) {
            all.filter { it != current }.random()
        } else {
            all[(current.ordinal + 1) % all.size]
        }
        activePreset.set(next)
        return next
    }

    fun startRecording() {
        synchronized(wavBuffer) { wavBuffer.reset() }
        isRecordingWav.set(true)
    }

    fun stopAndSaveWav(outFile: File): File {
        isRecordingWav.set(false)
        val pcmBytes = synchronized(wavBuffer) {
            val data = wavBuffer.toByteArray()
            wavBuffer.reset()
            data
        }
        FileOutputStream(outFile).use { fos ->
            val totalDataLen = pcmBytes.size + 36
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
                put("RIFF".toByteArray())
                putInt(totalDataLen)
                put("WAVE".toByteArray())
                put("fmt ".toByteArray())
                putInt(16)
                putShort(1)
                putShort(1)
                putInt(sampleRate)
                putInt(sampleRate * 2)
                putShort(2)
                putShort(16)
                put("data".toByteArray())
                putInt(pcmBytes.size)
            }
            fos.write(header.array())
            fos.write(pcmBytes)
        }
        return outFile
    }
}
